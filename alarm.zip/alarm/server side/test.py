import socket

# Create a socket object
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to the server
client_socket.connect(('94.74.145.190', 12345))

# Send data to the server
client_socket.sendall(b"Hello, this is a test message from the client!")

# Receive data from the server
data = client_socket.recv(1024)
print(f"Received data from server: {data.decode()}")

# Close the connection
client_socket.close()






