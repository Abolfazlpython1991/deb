import finpy_tse as tse
import pytse_client as tse_client
import socket
from sqlite3 import connect
from hashlib import sha256


USERNAME = ''
PASSWORD = ''
ALARMS_FILE = ''


def get_name_of_stocks():
    stocks = tse.Build_Market_StockList(bourse=True,
                                        farabourse=True,
                                        payeh=True,
                                        detailed_list=False,
                                        show_progress=False,
                                        save_excel=False,
                                        save_csv=False)
    stocks = stocks.index.to_list()
    return stocks


def get_datas_of_a_stock(stock_name, data):
    ticker = tse_client.Ticker(stock_name)
    match data:
        case 'history':
            return ticker.history
        case 'title':
            return ticker.title
        case 'url':
            return ticker.url
        case 'group_name':
            return ticker.group_name
        case 'eps':
            return ticker.eps
        case 'p_e_ratio':
            return ticker.p_e_ratio
        case 'group_p_e_ratio':
            return ticker.group_p_e_ratio
        case 'base_volume':
            return ticker.base_volume
        case 'last_price':
            return ticker.last_price
        case 'adj_close':
            return ticker.adj_close


def progress_data(data):
    try:
        return int(data)
    except:
        stock_name_and_attribute = data.replace('stock[', '')
        stock_name_and_attribute = stock_name_and_attribute.replace(']', '')
        stock_name, attribute = stock_name_and_attribute.split('.')
        return get_datas_of_a_stock(stock_name, attribute)


def call(phone_number, text):
    pass


def send_sms(phone_number, text):
    pass


def send_telegram_message(id, text):
    pass


def send_email(email_address, text):
    pass


def run_alarms():
    global USERNAME, ALARMS_FILE
    alarms_ = get_alarms()
    for alarm_ in alarms_:
        alarm = alarm_[1]
        do_not_run_commands = False
        alarm_items = alarm.replace('IF ')
        alarm_items = alarm_items.split('=>')
        alarm_ifs = alarm_items[0].split(',')
        commands = alarm_items[1].split(',')
        alarm_ifs.pop(-1)
        for alarm_if in alarm_ifs:
            if_items = alarm_if.split(':')
            data1 = progress_data(if_items[0])
            operator = if_items[1]
            data2 = progress_data(if_items[2])
            if operator == '>' and data1 > data2:
                pass
            elif operator == '<' and data1 < data2:
                pass
            elif operator == '==' and data1 == data2:
                pass
            elif operator == '<=' and data1 <= data2:
                pass
            elif operator == '>=' and data1 >= data2:
                pass
            elif operator == '!=' and data1 != data2:
                pass
            else:
                do_not_run_commands = True
                break
        if not do_not_run_commands:
            db_alarms = connect('alarms.db')
            cursor_alarms = db_alarms.cursor()
            db = connect('DataBase.db')
            cursor = db.cursor()
            cursor.execute(f"SELECT phone,telegram_id,email FROM users WHERE username='{USERNAME}'")
            phone, telegram_id, email = cursor.fetchall()[0]
            for command in commands:
                if command == 'send_sms':
                    send_sms(phone, 'هشدار! هشدار! یکی از شرط هایی که تعریف کرده بودید فعال شده است! سهام مدنظر خود را بررسی کنید')
                if command == 'call':
                    call(phone, 'یکی از شرط هایی که تعریف کرده بودید فعال شده است!')
                if command == 'send_telegram_message':
                    send_telegram_message(telegram_id, 'check your stocks => one of alarms turned on!')
                if command == 'send_email':
                    send_email(email, 'هشدار! هشدار! یکی از شرط هایی که تعریف کرده بودید فعال شده است! سهام مدنظر خود را بررسی کنید')
            cursor_alarms.execute(f"UPDATE '{ALARMS_FILE}' SET turn='off' WHERE id={alarm_[0]}")
            db_alarms.commit()
            db_alarms.close()
            db.close()


def get_usernames():
    db = connect('DataBase.db')
    cursor = db.cursor()
    cursor.execute("SELECT username FROM users")
    usernames = cursor.fetchall()
    db.commit()
    db.close()
    return usernames


def check_password(username, target_password):
    db = connect('DataBase.db')
    cursor = db.cursor()
    cursor.execute("SELECT password FROM users WHERE username = ?", (username,))
    password = cursor.fetchall()[0][0]
    print(password)
    db.commit()
    db.close()
    if target_password == password:
        return True
    else:
        return False


def get_alarms():
    global USERNAME, ALARMS_FILE
    alarms_db = connect('alarms.db')
    cursor = alarms_db.cursor()
    cursor.execute("SELECT * FROM ?", (ALARMS_FILE,))
    alarms = cursor.fetchall()
    alarms_db.close()
    return alarms


def get_id_alarm():
    global ALARMS_FILE
    db = connect('alarms.db')
    cursor = db.cursor()
    cursor.execute("SELECT id FROM {ALARMS_FILE};")
    ids_ = cursor.fetchall()
    ids = []
    for id in ids_:
        ids.append(int(id))
    id_index = 1
    for id in ids:
        if id_index != id:
            break
        else:
            id_index += 1


def set_alarms_file():
    global ALARMS_FILE, USERNAME
    db = connect('DataBase.db')
    cursor = db.cursor()
    cursor.execute("SELECT alarms_file FROM users WHERE username = ?", (USERNAME,))
    ALARMS_FILE = cursor.fetchall()[0]


def check_stock_exists(stock_name):
    stocks = get_name_of_stocks()
    if stock_name in stocks:
        return 'yes'
    else:
        return 'no'


def get_wallet_charge():
    global USERNAME
    db = connect('DataBase.db')
    cursor = db.cursor()
    cursor.execute("SELECT wallet_charge FROM users WHERE username = ?", (USERNAME,))
    wallet_charge = cursor.fetchall()[0][0]
    return wallet_charge


def new_user(username, password, email, phone, telegram_id):
    username = sha256(username.encode()).hexdigest()
    password = sha256(password.encode()).hexdigest()
    db = connect('DataBase.db')
    cur = db.cursor()
    index = str(int(open('number_of_alarm_file.txt', 'rt').read()) + 1)
    alarms_file = sha256(index.encode()).hexdigest()
    cur.execute(f"INSERT INTO users(username, password, alarms_file, email, phone, telegram_id) VALUES('{username}', '{password}', '{alarms_file}', '{email}', '{phone}', '{telegram_id}')")
    db.commit()
    db.close()
    alarms_db = connect('alarms.db')
    alarms_cur = alarms_db.cursor()
    alarms_cur.execute(f"CREATE TABLE '{alarms_file}'(id int, if VARCHAR(300), turn VARCHAR(5));")
    alarms_db.commit()
    alarms_db.close()
    file = open('number_of_alarm_file.txt', 'wt')
    file.write(str(int(index) + 1))
    file.close()


print('go to whiles...')
while True:
    print('listening...')
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.bind(("127.0.0.1", 4567))
    sock.listen()
    client, addr = sock.accept()
    sock = client
    userpass = (sock.recv(1024).decode('utf-8').replace('check_user:', '')).split('$')
    print(userpass)
    username, password = userpass[0], userpass[1]
    usernames_ = get_usernames()
    usernames = []
    for username_ in usernames_:
        usernames.append(username_[0])
    print('usernames: ', usernames)
    username = sha256(username.encode()).hexdigest()
    password = sha256(password.encode()).hexdigest()
    print(username, password)
    if username in usernames and check_password(username, password):
        PASSWORD = password
        USERNAME = username
        set_alarms_file()
        sock.send('yes'.encode())
        print(f'connected to {socket.gethostbyname(socket.gethostname())}:4567')
        try:
            msg = sock.recv(1024).decode()
            if not msg:
                print(msg)
        except:
            pass
        else:
            match msg:
                case 'get_stock_names':
                    sock.send(str(get_name_of_stocks()).encode())
                case 'get_alarms':
                    sock.send(str(get_alarms()).encode())
                case 'send_wallet_charge':
                    sock.send(str(get_wallet_charge()).encode())
                case _:
                    if 'check_stock_exists:' in msg:
                        stock_name = msg.replace('check_stock_exists:', '')
                        result = check_stock_exists(stock_name)
                        sock.send(result.encode())
                    elif 'set_alarm:' in msg:
                        alarm_if, turn = msg.replace('set_alarm:', '').split(':')
                        db = connect('alarms.db')
                        cursor = db.cursor()
                        id_alarm = get_id_alarm()
                        cursor.execute(f"INSERT INTO '{ALARMS_FILE}'(id, if, turn) VALUES(id_alarm, '{alarm_if}', turn);")
                        db.commit()
                        db.close()
                        sock.send(str(id_alarm).encode())
                    elif 'delete_alarm:' in msg:
                        alarm_id = msg.replace('delete_alarm:', '')
                        db = connect('alarms.db')
                        cursor = db.cursor()
                        cursor.execute(f"DELETE FROM alarms WHERE alarm_id = '{alarm_id}'")
                        db.commit()
                        db.close()
    else:
        sock.send('false'.encode())
        sock.close()




