from kivy.lang import Builder
from kivymd.app import MDApp
from pickle import dump, load
from os.path import exists
from socket import socket, AF_INET, SOCK_STREAM, gethostbyname, gethostname
from kivymd.uix.dialog import MDDialog, MDDialogButtonContainer, MDDialogHeadlineText
from kivymd.uix.selectioncontrol import MDSwitch
from kivymd.uix.list.list import MDListItem, MDListItemHeadlineText
import arabic_reshaper
from bidi.algorithm import get_display
from kivy.uix.spinner import Spinner

from kivy.animation import Animation

from kivy.metrics import dp


class MySwitch(MDSwitch):
    def on_thumb_down(self) -> None:
        print('changed')
        """
        Fired at the on_touch_down event of the :class:`~Thumb` object.
        Indicates the state of the switch "on/off" by an animation of
        increasing the size of the thumb.
        """

        if self.active:
            size = (dp(28), dp(28))
            print('a')
        else:
            size = (dp(24), dp(24))
            print('b')

        Animation(size=size, t="out_quad", d=0.2).start(self.ids.thumb)


class MySpinner(Spinner):
    ml = ['آباد', 'آبادا', 'آپ', 'آسیا', 'اپال', 'اتکام', 'اخابر', 'اردستان', 'اسیاتک', 'افق', 'البرز', 'امید', 'امین',
          'انرژی', 'بالبر', 'بترانس', 'برکت', 'بسویچ', 'بشهاب', 'بفجر', 'بکاب', 'بکام', 'بموتو', 'بنیرو', 'بورس',
          'بوعلی', 'پارس', 'پارسان', 'پارسیان', 'پاسا', 'پاکشو', 'پتایر', 'پترول', 'پدرخش', 'پرداخت', 'پردیس', 'پسهند',
          'پکرمان', 'پکویر', 'پلاسک', 'پی پاد', 'تاپیکو', 'تاصیکو', 'تایرا', 'تپمپی', 'تکاردان', 'تکشا', 'تکمبا',
          'تکنو', 'تملت', 'تنوین', 'تیپیکو', 'ثاخت', 'ثامان', 'ثامید', 'ثبهساز', 'ثشاهد', 'ثشرق', 'ثفارس', 'ثمسکن',
          'ثنوسا', 'جم', 'جم پیلن', 'چافست', 'چدن', 'چفیبر', 'چکاپا', 'چکارن', 'چکاوه', 'حپترو', 'حتاید', 'حتوکا',
          'حفارس', 'حفاری', 'حکشتی', 'خاذین', 'خاهن', 'خبهمن', 'خپویش', 'ختراک', 'ختور', 'ختوقا', 'خچرخش', 'خراسان',
          'خریخت', 'خرینگ', 'خزامیا', 'خزر', 'خساپا', 'خشرق', 'خفنر', 'خکار', 'خکمک', 'خگستر', 'خلنت', 'خمحرکه',
          'خمحور', 'خمهر', 'خموتور', 'خنصیر', 'خودرو', 'خوساز', 'دابور', 'داتام', 'دارو', 'داسوه', 'دالبر', 'دامین',
          'دانا', 'دپارس', 'دتماد', 'دجابر', 'ددام', 'درازک', 'دروز', 'دزهراوی', 'دسبحا', 'دسبحان', 'دسینا', 'دشیمی',
          'دعبید', 'دفارا', 'دفرا', 'دکوثر', 'دکیمی', 'دلر', 'دلقما', 'دیران', 'ذوب', 'رانفور', 'رتاپ', 'رکیش', 'رمپنا',
          'زپارس', 'زکوثر', 'زمگسا', 'سآبیک', 'ساراب', 'ساربیل', 'ساروم', 'سبجنو', 'سبهان', 'سپ', 'سپاها', 'سپید',
          'ستران', 'سخاش', 'سخزر', 'سخوز', 'سدشت', 'سدور', 'سرود', 'سشرق', 'سشمال', 'سصفها', 'سصوفی', 'سغرب', 'سفار',
          'سفارس', 'سفانو', 'سقاین', 'سکرد', 'سکرما', 'سمازن', 'سنیر', 'سهرمز', 'سهگمت', 'سیتا', 'سیدکو', 'سیستم',
          'سیلام', 'سیمرغ', 'شاراک', 'شاملا', 'شبریز', 'شبندر', 'شبهرن', 'شپارس', 'شپاکسا', 'شپدیس', 'شپنا', 'شتران',
          'شخارک', 'شدوص', 'شراز', 'شسپا', 'شستا', 'شسینا', 'شغدیر', 'شفا', 'شفارس', 'شفن', 'شکربن', 'شکلر', 'شگل',
          'شلعاب', 'شنفت', 'شهر', 'شوینده', 'شیراز', 'شیران', 'صبا', 'غاذر', 'غالبر', 'غبشهر', 'غبهنوش', 'غپاک',
          'غپینو', 'غچین', 'غدام', 'غدشت', 'غزر', 'غسالم', 'غشاذر', 'غشان', 'غشصفا', 'غشهد', 'غکورش', 'غگرجی', 'غگل',
          'غمهرا', 'غنوش', 'فاذر', 'فاراک', 'فارس', 'فاسمین', 'فاما', 'فایرا', 'فباهنر', 'فپنتا', 'فجام', 'فجر', 'فخاس',
          'فخوز', 'فرآور', 'فروس', 'فسازان', 'فسبزوار', 'فسپا', 'فسرب', 'فلامی', 'فلوله', 'فمراد', 'فملی', 'فنوال',
          'فنورد', 'فولاد', 'فولاژ', 'قپیرا', 'قثابت', 'قرن', 'قزوین', 'قشکر', 'قشهد', 'قصفها', 'قلرست', 'قمرو',
          'قنیشا', 'قهکمت', 'کاذر', 'کالا', 'کاما', 'کاوه', 'کبافق', 'کپارس', 'کپشیر', 'کترام', 'کچاد', 'کحافظ', 'کخاک',
          'کدما', 'کرازی', 'کرماشا', 'کروی', 'کساپا', 'کساوه', 'کسرا', 'کسرام', 'کسعدی', 'کطبس', 'کفپارس', 'کفرا',
          'کگاز', 'کگل', 'کلوند', 'کماسه', 'کمنگنز', 'کنور', 'کهمدا', 'کویر', 'کیمیا', 'کیمیاتک', 'لابسا', 'لبوتان',
          'لپارس', 'لخزر', 'لسرما', 'لوتوس', 'ما', 'مبین', 'مداران', 'ملت', 'میدکو', 'نمرینو', 'نوری', 'های وب',
          'همراه', 'وآذر', 'وآفری', 'واتی', 'واعتبار', 'والبر', 'وامید', 'وایران', 'وبانک', 'وبشهر', 'وبصادر', 'وبملت',
          'وبهمن', 'وبوعلی', 'وبیمه', 'وپارس', 'وپاسار', 'وپترو', 'وپخش', 'وپست', 'وتجارت', 'وتوس', 'وتوسم', 'وتوشه',
          'وتوصا', 'وتوکا', 'وخارزم', 'وخاور', 'ورنا', 'وساپا', 'وساخت', 'وساربیل', 'وساشرقی', 'وساغربی', 'وسبوشهر',
          'وسپه', 'وسخراج', 'وسخراش', 'وسخوز', 'وسرضوی', 'وسزنجان', 'وسصفا', 'وسفارس', 'وسقم', 'وسکاب', 'وسکرد',
          'وسکرشا', 'وسکرمان', 'وسکهبو', 'وسگلستا', 'وسگیلا', 'وسلرستا', 'وسمازن', 'وسمرکز', 'وسهرمز', 'وسهمدا',
          'وسیزد', 'وسیستا', 'وسیلام', 'وسینا', 'وصنا', 'وصندوق', 'وصنعت', 'وغدیر', 'وکار', 'وکغدیر', 'ولپارس',
          'ولساپا', 'ولصنم', 'ولغدر', 'ولکار', 'ولملت', 'ومدیر', 'ومعادن', 'وملی', 'ومهان', 'ونفت', 'ونوین', 'ونیرو',
          'ونیکی', 'آ س پ', 'آردینه', 'آریا', 'آریان', 'اپرداز', 'اتکای', 'ارفع', 'اعتلا', 'افرا', 'انتخاب', 'اوان',
          'بالاس', 'بپاس', 'بپیوند', 'بجهرم', 'بخاور', 'بزاگرس', 'بساما', 'بکابل', 'بکهنوج', 'بگیلان', 'بمپنا', 'بمولد',
          'بنو', 'بهپاک', 'بیوتیک', 'پارتا', 'پخش', 'پیزد', 'تاپکیش', 'تبرک', 'تپسی', 'تجلی', 'تلیسه', 'تماوند',
          'توریل', 'توسن', 'ثالوند', 'ثباغ', 'ثپردیس', 'ثتران', 'ثجنوب', 'ثرود', 'ثعمرا', 'ثغرب', 'چخزر', 'حآسا',
          'حآفرین', 'حپارسا', 'حپرتو', 'حخزر', 'حریل', 'حسیر', 'حسینا', 'حگهر', 'خاور', 'خدیزل', 'خکرمان', 'داوه',
          'دبالک', 'دتوزیع', 'دتولید', 'ددانا', 'درازی', 'درهآور', 'دسانکو', 'دقاضی', 'دکپسول', 'دماوند', 'رافزا',
          'رنیک', 'ریشمک', 'زاگرس', 'زبینا', 'زدشت', 'زشریف', 'زشگزا', 'زفجر', 'زفکا', 'زقیام', 'زکشت', 'زگلدشت',
          'زماهان', 'زملارد', 'زنگان', 'ساروج', 'سامان', 'ساوه', 'ساینا', 'سبزوا', 'سپیدار', 'سجام', 'سدبیر', 'سرچشمه',
          'سغدیر', 'سمگا', 'شاروم', 'شاوان', 'شبصیر', 'شپاس', 'شتوکا', 'شجم', 'شرانل', 'شصدف', 'شکام', 'شگویا', 'شملی',
          'عالیس', 'غپآذر', 'غپونه', 'غدانه', 'غدیس', 'غشهداب', 'غصینو', 'غفارس', 'غگلپا', 'غگلستا', 'غگیلا', 'غمایه',
          'غمینو', 'غویتا', 'فالوم', 'فتوسا', 'فجهان', 'فرابورس', 'فرود', 'فروژ', 'فروسیل', 'فروی', 'فزر', 'فزرین',
          'فسوژ', 'فصبا', 'فغدیر', 'فگستر', 'فن افزار', 'فنر', 'فولای', 'قاسم', 'قچار', 'قشیر', 'کاسپین', 'کایزد',
          'کپرور', 'کتوسعه', 'کتوکا', 'کرمان', 'کرومیت', 'کزغال', 'کشرق', 'کگهر', 'کلر', 'کمرجان', 'کوثر', 'کی بی سی',
          'گدنا', 'گکوثر', 'گلدیرا', 'گوهران', 'لطیف', 'مادیرا', 'مارون', 'مدیریت', 'مفاخر', 'میهن', 'ناما', 'نخریس',
          'نطرین', 'نوین', 'نیان', 'هجرت', 'هرمز', 'وآوا', 'والماس', 'وامین', 'وپویا', 'وتعاون', 'ودی', 'وسبحان',
          'وسپهر', 'وطوبی', 'وکبهمن', 'وگردش', 'وگستر', 'ولبهمن', 'ولتجار', 'ولشرق', 'ومعلم', 'وملل', 'وهامون', 'وهور',
          'کارام', 'فن آوا', 'شکبیر', 'کازرو', 'ممسنی', 'شلرد', 'وشمال', 'زنجان', 'غمارگ', 'تکیمیا', 'وبرق', 'استقلال',
          'پرسپولیس', 'دهدشت', 'نیرو', 'آینده', 'تفارس', 'ودانا', 'بمیلا', 'تکنار', 'داراب', 'فسا', 'جهرم', 'حرهشا',
          'معیار', 'بپردیس', 'سخواف', 'آرمان', 'وحکمت', 'خعمرا', 'حاریا', 'دشیری', 'فلات', 'کیسون', 'وکادو', 'وپسا',
          'بتک', 'غشوکو', 'شمواد', 'حبندر', 'شپلی', 'ولراز', 'ورازی', 'ثعتما', 'ویسا', 'ثنظام', 'وزمین', 'دی', 'شستان',
          'دحاوی', 'ثجوان', 'کصدف', 'کمینا', 'کباده', 'شساخت', 'وآفر', 'واحصا', 'واحیا', 'سفاسی', 'وملت', 'خفناور',
          'خکاوه', 'تشتاد', 'وفتخار', 'گکیش', 'جوین', 'لکما', 'وثوق', 'کابگن', 'لازما', 'فسدید', 'پلاست', 'پشاهن',
          'کقزوی', 'قجام', 'بایکا', 'غیوان', 'لپیام', 'غناب', 'وامیر', 'قنقش', 'سمایه', 'خصدرا', 'شفارا', 'وثنو',
          'کهرام', 'وسالت', 'گنگین', 'فنفت', 'اتکاسا', 'قیستو', 'شلیا', 'قشرین', 'وهنر', 'شزنگ', 'کایتا', 'لخانه',
          'غبهار', 'ثاژن', 'وشهر', 'خبازرس', 'وآرین', 'ثنام', 'شپترو', 'ومشان', 'ثنور', 'ثقزوی', 'سپرمی', 'ثاصفا',
          'ساذری', 'سایرا', 'چنوپا', 'ولانا', 'سباقر', 'سمتاز', 'تپکو', 'فجوش', 'کورز', 'گشان', 'وآیند', 'وسرمد',
          'وسنا', 'باران', 'وارس', 'رتکو', 'وآتوس', 'نبروج', 'ولیز', 'تمحرکه', 'فبستم', 'وحافظ', 'وثخوز', 'ولقمان',
          'قتربت', 'تاتمس', 'خبنیان', 'بازرگام', 'نشار', 'سفارود', 'فکمند', 'تفیرو', 'رفاه', 'نتوس', 'وسدید', 'شرنگی',
          'شتولی', 'خلیبل', 'وسین', 'وتوسکا', 'فافزا', 'خودکفا', 'شکف', 'کفرآور', 'تابا', 'فافق', 'فوکا', 'حشکوه',
          'بهیر', 'خپارس', 'شصفها', 'خفولا', 'حگردش', 'تپولا', 'قاروم', 'گپارس', 'بتهران', 'مرقام', 'وایرا', 'کاریز',
          'ثتوسا', 'فاهواز', 'فنرژی', 'وفردا', 'وجامی', 'آبین']

    def __init__(self, *args, **keys):
        super(MySpinner, self).__init__(**keys)
        new_ml = []
        self.font_name = 'arial.ttf'
        for item in self.ml:
            new_ml.append(get_display(arabic_reshaper.reshape((item))))

        new_ml.sort()
        self.values = new_ml


class Main(MDApp):

    def go_charge(self):
        pass

    def get_usernaame_():
        try:
            file = open('username_password.pickle', 'rb')
            userpass = load(file)
            print(userpass)
            username = userpass.split('$')[0]
            return f'username: {username}'
        except:
            return 'username: not login!'

    def get_wallet_charge():
        sock = socket(AF_INET, SOCK_STREAM)
        try:
            sock.connect(("94.74.145.190", 4567))
            file = open('username_password.pickle', 'rb')
            userpass = load(file)
            sock.send(userpass.encode())
            sock.send(f'send_wallet_charge'.encode())
            return f'wallet charge: {sock.recv(1024).decode()}'
        except:
            return 'wallet charge: Error!'

    wallet_charge = get_wallet_charge()
    get_username = get_usernaame_()
    About = '''
[font=arial.ttf][b][size=30]سازندگان[/size][/b]   
    [size=25][b]Client Side:[/b][/size]علی محمدزاده
    [b]Telegram:[/b] @AliKing2024Batman
    [b]Phone Number:[/b] +98 930 207 8955
    [b]مهارت ها : زبان پایتون و اکثر کتابخانه هایی اعم از: [/b]
    	socket, kivy, kivymd, telebot
    	
    [size=25][b]Server Side:[/b][/size] Abolfazl Scandary
    [b]Telegram:[/b] @Abolfazl_kali
    [b]Phone Number:[/b] +98 937 655 9007
    [b]مهارت ها : زبان های:[/b]
    	C++, Html, Python, PHP, Css
    [b]و کتابخانه های: [/b]
    	socket, tkinter, re, requests, nmap[/font]
    '''

    def go_main_page(self):
        def check_user_pass(username, password):
            sock = socket(AF_INET, SOCK_STREAM)
            sock.connect(("94.74.145.190", 4567))
            user_pass = username + '$' + password
            print(user_pass)
            sock.send(f'check_user:{user_pass}'.encode())
            result = sock.recv(1024).decode()
            print(f'result: {result}')
            sock.close()
            result = 'yes'
            return result

        username_ = self.root.ids.username.text
        password_ = self.root.ids.password.text
        userpass = f'{username_}${password_}'
        print('username: ', username_)
        print('password: ', password_)
        result = check_user_pass(username_, password_)
        if result == 'yes':
            self.root.current = 'main'
            file = open('username_password.pickle', 'wb')
            dump(userpass, file)
            file.close()
        else:
            print('username or password is false')

    def go_make_alarm_page(self):
        self.root.current = 'make alarm'

    def back(self):
        self.root.current = 'main'

    def create(self):
        txt_ = (self.root.ids.bit.text + ' ' + self.root.ids.info.text + ' ' +
                self.root.ids.iF.text + ' ' + self.root.ids.value.text + ' : ' + self.root.ids.command.text)
        if self.root.ids.bit.text != 'سهام' and self.root.ids.info.text != 'info' and self.root.ids.iF.text != 'if' and self.root.ids.value.text and self.root.ids.command.text != 'command':
            dialog = MDDialog(MDDialogHeadlineText(markup=True, text=f"[font=arial.ttf]{txt_}[/font]"),
                              MDDialogButtonContainer(MySwitch()))
            item = MDListItem(MDListItemHeadlineText(markup=True,
                                                     text=f'[font=arial.ttf]{self.root.ids.bit.text}[/font]'),
                              on_release=lambda *args: dialog.open())
            self.root.ids.Alarms.add_widget(item)

        self.root.current = 'main'
        self.root.ids.value.text = ''
        self.root.ids.iF.text = 'if'
        self.root.ids.bit.text = get_display(arabic_reshaper.reshape(('سهام')))
        self.root.ids.info.text = 'info'

    def refresh_and_show_alarms(self):
        self.root.ids.Alarms.clear_widgets()

        def get_alarms_from_server(user_name_, password_):
            sock = socket(AF_INET, SOCK_STREAM)
            sock.connect(('94.74.145.190', 4567))
            sock.send(f"send_my_alarms:{user_name_ + '$' + password_}".encode())
            result = eval(sock.recv(1024).decode())
            result = [['آخرین قیمت' + ' وخودرو ' + '> ' + '500 : sms', 'وخودرو']]
            return result

        file = open('username_password.pickle', 'rb')
        userpass = load(file)
        username_ = userpass.split('$')[0]
        password_ = userpass.split('$')[1]
        alarms_ = get_alarms_from_server(username_, password_)
        for alarm in alarms_:
            dialog = MDDialog(MDDialogHeadlineText(markup=True, text=f"[font=arial.ttf]{alarm[0]}[/font]"),
                              MDDialogButtonContainer(MDSwitch()))
            item = MDListItem(MDListItemHeadlineText(markup=True,
                                                     text=f'[font=arial.ttf]{alarm[1]}[/font]'),
                              on_release=lambda *args: dialog.open())
            self.root.ids.Alarms.add_widget(item)

    def build(self):
        def check_user_pass(username, password):
            sock = socket(AF_INET, SOCK_STREAM)
            sock.connect(("94.74.144.190", 4567))
            user_pass = username + '$' + password
            print(user_pass)
            sock.send(f'check_user:{user_pass}'.encode())
            result = sock.recv(1024).decode()
            print(f'result: {result}')
            sock.close()
            result = 'yes'
            return result

        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Olive"
        if not exists('username_password.pickle'):
            return Builder.load_file('graph1.kv')

        else:
            file = open('username_password.pickle', 'rb')
            userpass = load(file)
            username_ = userpass.split('$')[0]
            password_ = userpass.split('$')[1]
            result = check_user_pass(username=username_, password=password_)
            if result == 'yes':
                return Builder.load_file('graph2.kv')
            else:
                return Builder.load_file('graph1.kv')


Main().run()
