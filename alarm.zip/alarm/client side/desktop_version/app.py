from socket import socket, AF_INET, SOCK_STREAM, gethostbyname, gethostname

password = 'Abolfazl_kali_1389'
username = 'abolfazl'
sock = ''


def login_to_server():
    global username, password, sock
    sock = socket(AF_INET, SOCK_STREAM)
    sock.connect((gethostbyname(gethostname()), 4567))
    sock.send(f'{username}${password}'.encode())
    if sock.recv(1024).decode() == 'wellcome':
        return True
    else:
        return False


def get_stock_names():
    global sock
    sock.send('get_stock_names'.encode())
    return sock.recv(1024).decode()


def check_stock_exists(stock_name):
    global sock
    sock.send(f'check_stock_exists:{stock_name}'.encode())
    if sock.recv(1024).decode() == 'yes':
        return True
    else:
        return False


def set_alarm(stock_name, operator, data1, data2):
    global sock
    sock.send(f'set_alarm:{stock_name}:{operator}:{data1}:{data2}'.encode())
    if sock.recv(1024).decode() == 'setup':
        return True
    else:
        return False


def get_alarms():
    global sock
    sock.send('get_alarms'.encode())
    return sock.recv(1024).decode()


def delete_alarm(id):
    global sock
    sock.send(f'delete_alarm:{id}'.encode())
    if sock.recv(1024).decode() == 'deleted':
        return True
    else:
        return False


login_to_server()
print(get_stock_names())
